@extends('layouts.app')
@section('content')
    <div class="container page-title bg-green text-white p-3">
        Club Distances
    </div>

    <div class="container">

    </div>
@endsection