@extends('layouts.app')
@section('content')
    <div class="container">
        <h1>About</h1>
        <div class="row col-sm-12 mt-0 mb-2 pt-0 pb-0">
            <span class="col-sm-2 hr-left"></span>
            <span class="col-sm-10  hr-right"></span>
        </div>
        <h2>Way To Golf</h2>
        <p>
            This goes into the description of the website.
        </p>
        <a href="" style="color: darkorange;"><b>For More Information</b></a>
    </diV>
@endsection