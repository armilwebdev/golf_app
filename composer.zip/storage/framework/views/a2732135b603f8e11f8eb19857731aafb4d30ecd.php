<?php $__env->startSection('content'); ?>
    <div class="golf-cover">
    </div>
        <div class="container dashboard-container bg-none">
        <div class="row">
            <div class="col-md-12 page-title text-center">
                    Dashboard
            </div>
        </div>
        <div class="row justify-content-center">

            
            <div class="col-md-4 col-sm-12 mb-4">
                <div class="card pr-0 pl-0 bg-none" >
                    <span class="card-header dashboard-card-header">Golf Bag</span>
                    <div class="card-body  bg-green">
                        <span class="card-desc">Current Clubs - <b><?php echo e(count($clubs)); ?></b></span>
                        <p class="card-text">
                        <div class="accordion" id="accordionExample">
                            <a href="/modify_bag" class="btn btn-orange">Modify Bag</a><br>
                            <button class="btn btn-link text-primary bold" style="font-size:1em;" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                View Clubs
                            </button>
                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                                    <ul class="golf-clubs-list list-group list-group-flush bg-green border">
                                        
                                        <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item bg-green"><?php echo e($club->club); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        </p>
                        
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 col-sm-12 mb-4">
                <div class="card pr-0 pl-0 bg-none" >
                    <span class="card-header dashboard-card-header">Golf Range</span>
                    <div class="card-body bg-green">
                        <p class="card-text">
                            <span class="card-desc">Record your club distances</span>
                        </p>
                        <a href="/club_distance" class="btn btn-orange">Go</a>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4 col-sm-12 mb-4">
                <div class="card pr-0 pl-0 bg-none" >
                    <span class="card-header dashboard-card-header">Club Distance</span>
                    <div class="card-body bg-green">
                        <p class="card-text">
                            <span class="card-desc">View distance avg for each club</span>
                        </p>
                        <a href="/distances" class="btn btn-orange">Go</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\golf\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>