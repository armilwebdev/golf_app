<?php $__env->startSection('content'); ?>
<div class="golf-cover enable-blur">
    <div class="home-title col-md-5 col-sm-12">
            <span class="darkorange">Way to <?php echo e(config('app.name', 'golf')); ?></span>
        <div class="home-description">
            Keep track of your golf club distances to help you select the proper club on the course.
        </div>
        <?php if(auth()->guard()->guest()): ?>
        <div class="register-buttons">
             <a href="login" class="btn btn-lg btn-outline-light loginbtn">Login</a>
             <a href="register" class=" registerbtn text-light">Register</a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\golf\resources\views/pages/index.blade.php ENDPATH**/ ?>