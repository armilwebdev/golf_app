<?php $__env->startSection('content'); ?>
    <div class="container page-title bg-green text-white p-3">
        Club Distances
    </div>

    <div class="container">

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\golf\resources\views/pages/showclub.blade.php ENDPATH**/ ?>