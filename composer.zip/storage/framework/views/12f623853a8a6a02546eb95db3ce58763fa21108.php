<?php $__env->startSection('content'); ?>
  

    <div class="container">
    <div class="page-title text-dark p-3">
            Club Distances
        </div>
        <table class="table bg-light table-striped">
            <thead class="bg-green">
                <tr>
                    <th>Club</th>
                    <th>Avg Distance (yds)</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                    <?php echo Form::open(['action' => 'Distances@distances', 'method' => 'POST']); ?>


                <?php $table_row_count = 0;?>
                <?php $__currentLoopData = $default_clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $default_club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $distance_total = 0;
                    $club_count = 0;
                    $club_item = $default_club->club;
                    
                ?>
                <tr>
                    <td><a href="showclub/<?php echo e($club_item); ?>" class="club-table-title"><?php echo e($club_item); ?></a></td>
                        <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $row_count      = 0;
                                $club           = $user_club->club;
                                $club_distance  = $user_club->distance;
                            ?>
                            <?php if($club == $club_item): ?>
                                <?php if(++$row_count == 10): ?>
                                    <?php
                                    continue;
                                    ?>
                                <?php endif; ?>
                                <?php
                                    $distance_total+=$club_distance;
                                    $club_count++;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($distance_total < 1): ?>
                                <?php
                                ?>
                                <td>-</td>
                                <td></td>
    

                                <?php else: ?>
                            <?php
                                $distance = $distance_total/$club_count;
                                $distance = number_format($distance, 2);
                                $table_row_count++;

                            ?>
                            
                            <td><?php echo e($distance); ?></td>
                            <td>
                                <input type="text" value="<?php echo e($club_item); ?>" name="club_item<?php echo e($table_row_count); ?>" hidden>
                                <button class="btn btn-light btn-outline-success" value="btn-reset<?php echo e($table_row_count); ?>" name="btn-reset<?php echo e($table_row_count); ?>" type="submit">Clear</button>
                            </td>
                            <?php endif; ?> 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e(Form::hidden('_method', 'GET')); ?>


                <?php echo Form::close(); ?>


            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\golf\resources\views/pages/distances.blade.php ENDPATH**/ ?>