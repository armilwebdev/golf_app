<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 page-title text-center">
                    Golf Bag
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 page-description">
                <b>Golf Bag</b><br>
                Total Clubs: <?php echo e(count($clubs )); ?>

                <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                   <div><?php echo e($club->club); ?></div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a class="btn btn-lg  btn-primary" href="/modify_bag">Add to Bag</a>
            </div>
            <div class="col-md-4 page-description">
                    <b>Golf Range</b><br>
                    Record Your Distances<br>
                <a class="btn btn-lg  btn-primary" href="/club_distance">Golf Range</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\golf\resources\views/pages/bag.blade.php ENDPATH**/ ?>