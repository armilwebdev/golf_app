<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GolfClubs extends Model
{
    protected $table = 'golf_clubs';

}
