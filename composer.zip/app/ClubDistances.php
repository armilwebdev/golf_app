<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClubDistances extends Model
{
    protected $table = 'club_distances';
    
}
