<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class clubs extends Model
{
    protected $table = 'clubs';
    

}
