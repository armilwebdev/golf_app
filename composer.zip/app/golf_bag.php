<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class golf_bag extends Model
{
    
}
